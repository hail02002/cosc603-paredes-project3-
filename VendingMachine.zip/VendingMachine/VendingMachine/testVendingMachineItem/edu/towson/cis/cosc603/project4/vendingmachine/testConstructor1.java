package edu.towson.cis.cosc603.project4.vendingmachine;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

/**
 * Here the constructor is test with bad inputs
 * @author Henrys Laptop 2
 *
 */
public class testConstructor1 {

	private VendingMachineItem item;
	
	@Before
	public void setUp() throws Exception {
		item = new VendingMachineItem(null, 1);
	}

	@Test(expected = NullPointerException.class)
	public void testVendingMachineItem0() {
		assertEquals(item.getName(), null);
	}

	@Test(expected = RuntimeException.class)
	public void testVendingMachineItem1() {
		VendingMachineItem item0 = new VendingMachineItem("snickers", -1); 
		assertEquals(item0.getPrice(), 0, 0.0001);
	}

}
