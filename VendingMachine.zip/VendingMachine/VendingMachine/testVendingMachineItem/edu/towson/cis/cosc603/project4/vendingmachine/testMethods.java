package edu.towson.cis.cosc603.project4.vendingmachine;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

/**
 * Here the methods getName and getPrice 
 * is tested with good inputs
 * @author Henrys Laptop 2
 *
 */
public class testMethods {

	private VendingMachineItem item;
	private String name;
	private double price;
	
	@Before
	public void setUp() throws Exception {
		name = "Snickers";
		price = 1;
		item = new VendingMachineItem(name, price);
	}

	@Test
	public void testMethods() {
		assertEquals(item.getName(), name);
		assertEquals(item.getPrice(), price, 0.0001);
	}

}
