package edu.towson.cis.cosc603.project4.vendingmachine;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

/**
 * Here the constructor is tested with good inputs
 * @author Henrys Laptop 2
 *
 */
public class testConstructor0 {

	private VendingMachineItem item;
	@Before
	public void setUp() throws Exception {
		item = new VendingMachineItem("Snickers", 1);
	}

	@Test
	public void testVendingMachineItem() {
		assertEquals(item.getName(), "Snickers");
		assertEquals(item.getPrice(), 1, 0.0001);		
	}

}
