package edu.towson.cis.cosc603.project4.vendingmachine;


import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
/**
 * Here the method returnChange() is tested
 * @author Henrys Laptop 2
 *
 */
public class testReturnChange {

	private VendingMachine myMachine;
	private VendingMachineItem item;

	@Before
	public void setUp() throws Exception {
		myMachine = new VendingMachine();
		item = new VendingMachineItem("Snickers", 1.00);
		myMachine.addItem(item, "A");		
	}

	@Test
	public void testReturnChange() {
		myMachine.insertMoney(0.50);
		myMachine.makePurchase("A");
		double change = myMachine.returnChange();
		assertEquals(change, 0.50, 0.0001);
	}

}
