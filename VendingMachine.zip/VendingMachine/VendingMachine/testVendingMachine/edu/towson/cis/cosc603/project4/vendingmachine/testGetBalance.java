package edu.towson.cis.cosc603.project4.vendingmachine;

import static org.junit.Assert.*;

import javax.xml.ws.soap.MTOM;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

/**
 * Here the method getBalance()is tested
 * @author Henrys Laptop 2
 *
 */
public class testGetBalance {

	private VendingMachine myMachine;
	
	@Before
	public void setUp() throws Exception {
		myMachine = new VendingMachine();
	}

	@Test
	public void testGetBalance() {
		double startAmount = myMachine.getBalance();
		double amount = 0.50;
		myMachine.insertMoney(amount);
		startAmount += amount;
		assertEquals(startAmount, myMachine.getBalance(), 0.0001);
	}

}
