package edu.towson.cis.cosc603.project4.vendingmachine;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

/**
 * Here the method removeItem() precondition and
 * postcondition are tested 
 * @author Henrys Laptop 2
 *
 */
public class testRemoveItem {

	private VendingMachine myMachine;
	private VendingMachineItem item;
	private String name, code;
	private double price;

	@Before
	public void setUp() throws Exception {
		myMachine = new VendingMachine();
		name = "Snickers";
		code = "A";
		price = 1.0;
		item = new VendingMachineItem(name, price);
		myMachine.addItem(item, code);
		
	}

	@Test(expected=NullPointerException.class)
	public void testRemoveItem() {
		myMachine.removeItem(code);
		item = myMachine.getItem(code);
		assertEquals(item.getName(), null);
	}

}
