package edu.towson.cis.cosc603.project4.vendingmachine;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

/**
 * Here the method addItem() precondition and
 * postcondition are tested 
 * @author Henrys Laptop 2
 *
 */
public class testAddItem {

	private VendingMachine myMachine;
	private VendingMachineItem item;
	private String name, code;
	private double price;
	
	@Before
	public void setUp() throws Exception {
		myMachine = new VendingMachine();
		name = "Snickers";
		code = "A";
		price = 1.0;
		VendingMachineItem item = new VendingMachineItem(name, price);
		myMachine.addItem(item, code);
	}

	@Test(expected=VendingMachineException.class)
	public void testAddItem0() {
		VendingMachineItem item0 = new VendingMachineItem(" snickers", 1);
		myMachine.addItem(item0, code);
		myMachine.addItem(item0, "a");
	}

	@Test(expected=VendingMachineException.class)
	public void testAddItem1() {
		VendingMachineItem item0 = new VendingMachineItem(" snickers", 1);
		myMachine.addItem(item0, "a");
	}
	
}
